from math import sqrt
import torch
from torch_geometric.nn import MessagePassing
import copy
import math
import numpy as np
import explain_module.utils
import sys
EPS = 1e-10
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

class Meta_LT_GNNGExplainer(torch.nn.Module):

    coeffs = {
        'edge_size': 0.05,
        'edge_ent': 0.5,
    }

    def __init__(self, model, epochs, lr=0.01, log=True):
        super(Meta_LT_GNNGExplainer, self).__init__()
        self.model = model
        self.model.to(device)
        self.epochs = epochs
        self.lr = lr
        self.log = log

    def __set_masks__(self, x, edge_index,N,init="normal"):      ###fjf 把每个图的mask区别固定
        #考虑到可能往后去初始mask的差距太大了 不太行
        E = edge_index.size(1)

        std = torch.nn.init.calculate_gain('relu') * sqrt(2.0 / (2 * N))
        self.edge_mask = torch.nn.Parameter(torch.randn(E) * std)

        for module in self.model.modules():
            if isinstance(module, MessagePassing):
                module.__explain__ = True
                module.__edge_mask__ = self.edge_mask   #fjf edge_mask的内部实现 也可外部实现

    def __clear_masks__(self):
        for module in self.model.modules():
            if isinstance(module, MessagePassing):
                module.__explain__ = False
                module.__edge_mask__ = None
        self.edge_mask = None   #fjf self的edgemask怎么没定义就直接赋值None了 可能是父类中有

    def __loss__(self, log_logits, pred_label):

        loss = -log_logits[0, pred_label]   #这个0我真的很纳闷 不应该换成‘：’吗 FIXME
        m = self.edge_mask.sigmoid()
        #fjf eg对于平均node=30的MUTAG m几乎都是0.5了 意义何在
        #或者说 先randn 再sigmod的意义在：
        # ①初始化集中在0.5左右 大的往上 小的往下 可能理想的结果是最终变成1 0形式
        # ②sigmod后处于中间状态（靠近0.5）mask的个体移动更快 TODO
        loss = loss + self.coeffs['edge_size'] * m.sum()  #fjf mask的L1
        ent = -m * torch.log(m + EPS) - (1 - m) * torch.log(1 - m + EPS)  #fjf 限制软掩码
        loss = loss + self.coeffs['edge_ent'] * ent.mean()
        return loss

    def explain_graph(self, graph_old, lt_epochs=2):
        mask=()
        top_ratio_every_time=[1 if i==1 else round(1-1/i,5) for i in range(lt_epochs,0,-1)]  #每次保留子图的比例[3/4,2/3,1/2,1]
        self.__clear_masks__()
        graph=graph_old
        N=graph.x.size(0)
        num_edges = graph.edge_index.size(1)

        # Get the initial prediction.
        with torch.no_grad():
            log_logits = self.model(x=graph.x,
                                    edge_index=graph.edge_index,
                                    edge_attr=graph.edge_attr,
                                    batch=graph.batch)
            pred_label = log_logits.argmax(dim=-1)
        for i in range(lt_epochs):
            self.__set_masks__(graph.x, graph.edge_index,N)
            self.to(graph.x.device)

            optimizer = torch.optim.Adam([self.edge_mask], lr=self.lr)

            for epoch in range(1, self.epochs + 1):

                optimizer.zero_grad()
                log_logits = self.model(x=graph.x,
                                    edge_index=graph.edge_index,
                                    edge_attr=graph.edge_attr,
                                    batch=graph.batch)
                loss = self.__loss__(log_logits, pred_label)

                loss.backward()
                optimizer.step()

            edge_mask = self.edge_mask.detach().sigmoid()
            mask+=(edge_mask,)
            self.__clear_masks__()

            graph=self.pack_explanatory_subgraph(graph,edge_mask,top_ratio=top_ratio_every_time[i])
        # print(mask)
        # print(top_ratio_every_time)
        lt_mask=self.combine_mask(mask,top_ratio_every_time=top_ratio_every_time)
        # print(lt_mask)
        return lt_mask


    def __repr__(self):
        return f'{self.__class__.__name__}()'


    def pack_explanatory_subgraph(self, graph,imp,top_ratio):
        #fjf 根据last—result获取新图（top_ratio为每次保留的边比例
        top_idx = torch.LongTensor([])
        graph_map = graph.batch[graph.edge_index[0, :]]   #fjf 获取边的隶属关系
        exp_subgraph = copy.deepcopy(graph)
        exp_subgraph.y = graph.y

        for i in range(graph.num_graphs):
            edge_indicator = torch.where(graph_map == i)[0].detach().cpu()
            Gi_n_edge = len(edge_indicator)
            topk = max(math.floor(top_ratio * Gi_n_edge), 1)

            Gi_pos_edge_idx = np.argsort(-imp[edge_indicator].cpu())[:topk]
            top_idx = torch.cat([top_idx, edge_indicator[Gi_pos_edge_idx]])   #fjf保留的边ind
        # retrieval properties of the explanatory subgraph
        # .... the edge_attr.
        exp_subgraph.edge_attr = graph.edge_attr[top_idx]
        # .... the edge_index.
        exp_subgraph.edge_index = graph.edge_index[:, top_idx]
        # .... the nodes.
        # exp_subgraph.x = graph.x
        exp_subgraph.x, exp_subgraph.edge_index, exp_subgraph.batch = \
            self.__relabel__(exp_subgraph, exp_subgraph.edge_index)

        return exp_subgraph

    def __relabel__(self, g, edge_index):
        #fjf将x和edge_index和batch去掉删除的 eg：[[2,5,7,8][5,2,8,7]]→[[1,2,3,4][2,1,4,3]]

        sub_nodes = torch.unique(edge_index)
        x = g.x[sub_nodes]
        batch = g.batch[sub_nodes]
        row, col = edge_index

        # remapping the nodes in the explanatory subgraph to new ids.
        node_idx = row.new_full((g.num_nodes,), -1)
        node_idx[sub_nodes] = torch.arange(sub_nodes.size(0), device=row.device)
        edge_index = node_idx[edge_index]
        return x, edge_index, batch

    def combine_mask(self,mask, top_ratio_every_time):
        lt_num = len(mask)
        for i in range(lt_num - 1, 0, -1):
            top_ratio=top_ratio_every_time[i-1]
            Gi_edge_idx = len(mask[i - 1])
            topk = max(math.floor(top_ratio * Gi_edge_idx), 1)
            Gi_pos_edge_idx = np.argsort(-np.abs(mask[i - 1].cpu()))[:topk]
            diff_every_time = max(mask[i - 1]) - min(mask[i]) + 1e-4
            for k, index in enumerate(np.unique(Gi_pos_edge_idx)):
                mask[i - 1][int(index)] = mask[i][k] + diff_every_time
        return mask[0]

        ###for example: print(combine_mask(([3,6,1,0,4,2,5],[1.1,3.1,2.1,4.1],[4.2,3.2]),[0.667,0.50,1.00]))

