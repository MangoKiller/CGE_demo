import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.data import Data, DataLoader
from torch_geometric.nn import GCNConv
from torch_scatter import scatter_max
import matplotlib.pyplot as plt
from explain_module.data_loader_zoo.mnist_dataloader  import Mnist
import sys
from tqdm import tqdm

data_size = 5000
train_size = 4000
batch_size = 100
epoch_num = 100


class MnistNet(torch.nn.Module):
	def __init__(self):
		super(MnistNet, self).__init__()
		self.conv1 = GCNConv(2, 16)
		self.conv2 = GCNConv(16, 32)
		self.conv3 = GCNConv(32, 48)
		self.conv4 = GCNConv(48, 64)
		self.conv5 = GCNConv(64, 96)
		self.conv6 = GCNConv(96, 128)
		self.linear1 = torch.nn.Linear(128, 64)
		self.linear2 = torch.nn.Linear(64, 10)

	def forward(self, x, edge_index, edge_attr, batch):
		x, edge_index = x, edge_index
		x = self.conv1(x, edge_index)
		x = F.relu(x)
		x = self.conv2(x, edge_index)
		x = F.relu(x)
		x = self.conv3(x, edge_index)
		x = F.relu(x)
		x = self.conv4(x, edge_index)
		x = F.relu(x)
		x = self.conv5(x, edge_index)
		x = F.relu(x)
		x = self.conv6(x, edge_index)
		x = F.relu(x)
		x, _ = scatter_max(x, batch, dim=0)
		x = self.linear1(x)
		x = F.relu(x)
		x = self.linear2(x)
		return x

	def reset_parameters(self):
		with torch.no_grad():
			for param in self.parameters():
				param.uniform_(-1.0, 1.0)

def main():
	# 前準備
	mnist_list = Mnist(data_size=data_size)
	device = torch.device('cuda')
	model = MnistNet().to(device)
	trainset = mnist_list[:train_size]
	optimizer = torch.optim.Adam(model.parameters())
	trainloader = DataLoader(trainset, batch_size=batch_size, shuffle=True)
	testset = mnist_list[train_size:]
	testloader = DataLoader(testset, batch_size=batch_size)
	criterion = nn.CrossEntropyLoss()
	history = {
		"train_loss": [],
		"test_loss": [],
		"test_acc": []
	}
	# for i,j in enumerate(trainset):
	#     print(j)
	# sys.exit()
	print("Start Train")

	# 学習部分
	model.train()
	for epoch in tqdm(range(epoch_num)):
		train_loss = 0.0
		for i, batch in enumerate(trainloader):
			batch = batch.to("cuda")
			optimizer.zero_grad()
			outputs = model(batch.x, batch.edge_index, batch.edge_attr, batch.batch)
			loss = criterion(outputs, batch.y)
			loss.backward()
			optimizer.step()

			train_loss += loss.cpu().item()
			if i % 10 == 9:
				progress_bar = '[' + ('=' * ((i + 1) // 10)) + (' ' * ((train_size // 100 - (i + 1)) // 10)) + ']'
				print('\repoch: {:d} loss: {:.3f}  {}'
					  .format(epoch + 1, loss.cpu().item(), progress_bar), end="  ")

		print('\repoch: {:d} loss: {:.3f}'
			  .format(epoch + 1, train_loss / (train_size / batch_size)), end="  ")
		history["train_loss"].append(train_loss / (train_size / batch_size))

		correct = 0
		total = 0
		batch_num = 0
		loss = 0
		with torch.no_grad():
			for data in testloader:
				data = data.to(device)
				outputs = model(batch.x, batch.edge_index, batch.edge_attr, batch.batch)
				loss += criterion(outputs, data.y)
				_, predicted = torch.max(outputs, 1)
				total += data.y.size(0)
				batch_num += 1
				correct += (predicted == data.y).sum().cpu().item()

		history["test_acc"].append(correct / total)
		history["test_loss"].append(loss.cpu().item() / batch_num)
		endstr = ' ' * max(1, (train_size // 1000 - 39)) + "\n"
		print('Test Accuracy: {:.2f} %%'.format(100 * float(correct / total)), end='  ')
		print(f'Test Loss: {loss.cpu().item() / batch_num:.3f}', end=endstr)
	torch.save(model, 'E:/USTC/CODE_ZERO/Causal-Screening-master-fjf/explain_module/mnist_net.pt')

	print('Finished Training')

	# 最終結果出力
	correct = 0
	total = 0
	with torch.no_grad():
		for data in testloader:
			data = data.to(device)
			outputs = model(batch.x, batch.edge_index, batch.edge_attr, batch.batch)
			_, predicted = torch.max(outputs, 1)
			total += data.y.size(0)
			correct += (predicted == data.y).sum().cpu().item()
	print('Accuracy: {:.2f} %%'.format(100 * float(correct / total)))


if __name__ == "__main__":
	main()